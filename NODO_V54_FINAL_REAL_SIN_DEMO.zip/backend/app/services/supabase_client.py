from supabase import create_client
from app.core.config import settings
from functools import lru_cache
@lru_cache
def get_supabase():
    return create_client(settings.SUPABASE_URL, settings.SUPABASE_SERVICE_ROLE_KEY)
supabase=get_supabase()
