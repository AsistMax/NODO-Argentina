
import httpx
from bs4 import BeautifulSoup
import uuid
from datetime import datetime
from app.services.supabase_client import supabase
import logging
logger = logging.getLogger("scraper")

FUENTES = [
    {"nombre": "Clasificados Catamarca", "url": "https://www.google.com/search?q=necesito+albañil+catamarca", "tipo": "albanil"},
]

async def ejecutar_todos_los_bots_scrapers():
    tareas = []
    try:
        async with httpx.AsyncClient(timeout=15, headers={"User-Agent":"Mozilla/5.0 NODO Bot"}, follow_redirects=True) as client:
            for fuente in FUENTES:
                try:
                    r = await client.get(fuente["url"])
                    if r.status_code==200:
                        tareas.append({"id": f"scraped_{uuid.uuid4().hex[:8]}", "titulo": f"Cliente necesita {fuente['tipo']} - {fuente['nombre']}", "rubro": fuente['tipo'], "fuente": fuente['nombre']})
                except Exception as e:
                    logger.error(e)
        # Guardar en Supabase
        for t in tareas:
            try:
                supabase.table("tareas_reales").upsert({"id": t["id"], "titulo": t["titulo"], "empresa": t["fuente"], "direccion": "Catamarca", "lat": -28.46957, "lon": -65.78524, "km": 2.0, "tarifa": 2000, "descripcion": "Scrapeado", "estado": "DISPONIBLE_SCRAPER", "creado": datetime.utcnow().isoformat()}, on_conflict="id").execute()
            except Exception as e:
                logger.error(e)
    except Exception as e:
        logger.error(e)
    return tareas
