from pydantic_settings import BaseSettings
class Settings(BaseSettings):
    SUPABASE_URL: str
    SUPABASE_SERVICE_ROLE_KEY: str
    FIREBASE_STORAGE_BUCKET: str
    MP_ACCESS_TOKEN: str
    MP_PUBLIC_KEY: str
    MP_COMMISSION_EMAIL: str
    ADMIN_KEY: str
    SMTP_CORREO: str=''
    SMTP_PASSWORD: str=''
    BASE_URL: str='https://maxshop-api.onrender.com'
    SECRET_KEY: str
    NODO_BASE_FEE: int=1500
    NODO_PER_KM: int=350
    NODO_COMMISSION: float=0.15
    class Config:
        env_file='.env'
        extra='allow'
settings=Settings()
