
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
import logging, httpx, os
from app.core.config import settings
from app.services.supabase_client import supabase
from pydantic import BaseModel
import mercadopago, uuid
from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("nodo_v55")
scheduler = BackgroundScheduler()
sdk = mercadopago.SDK(settings.MP_ACCESS_TOKEN)

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("NODO V55 REAL - MP PAYOUT + SCRAPER")
    try:
        from app.scrapers.scraper_catamarca_real import ejecutar_todos_los_bots_scrapers
        scheduler.add_job(lambda: __import__('asyncio').run(ejecutar_todos_los_bots_scrapers()), 'interval', minutes=15, id='bots_real', replace_existing=True)
        scheduler.start()
    except Exception as e:
        logger.error(e)
    yield

app = FastAPI(title="NODO V55 REAL", version="55.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
if os.path.exists("frontend/bloque1"):
    app.mount("/bloque1", StaticFiles(directory="frontend/bloque1", html=True), name="bloque1")
    app.mount("/", StaticFiles(directory="frontend/bloque1", html=True), name="root")

@app.get("/health")
def health():
    return {"status":"ok","version":"V55 MP PAYOUT + SCRAPER REAL","modelo":"SIN WALLET PENDIENTE SPLIT"}

class Solicitud(BaseModel):
    tarea_id: str
    email_cliente: str
    origen: dict
    destino: dict
    distancia_km: float

@app.post("/api/v1/servicios/solicitar")
def solicitar(req: Solicitud):
    tarifa = int(settings.NODO_BASE_FEE + (req.distancia_km * settings.NODO_PER_KM))
    # Crear pago MP real a tu cuenta
    payment_data = {"transaction_amount": float(tarifa), "description": f"NODO+ {req.tarea_id}", "payer": {"email": req.email_cliente}, "external_reference": req.tarea_id, "binary_mode": True}
    result = sdk.payment().create(payment_data)
    if result.get("status") in [200,201]:
        try:
            supabase.table("pagos_pendientes").insert({"id": str(uuid.uuid4()), "tarea_id": req.tarea_id, "monto_total": tarifa, "comision_nodo": int(tarifa*0.15), "monto_profesional": int(tarifa*0.85), "estado": "PENDIENTE_SPLIT", "mp_payment_id": result["response"]["id"], "email_cliente": req.email_cliente, "creado": datetime.utcnow().isoformat()}).execute()
        except Exception as e:
            print(e)
    return {"ok": True, "tarifa": tarifa, "estado": "PENDIENTE_SPLIT", "mp": result.get("response",{})}

class Llegada(BaseModel):
    tarea_id: str
    foto_comprobante_url: str
    lat: float
    lon: float
    email_profesional: str = ""

@app.post("/api/v1/servicios/llegue")
def llegue(req: Llegada):
    try:
        supabase.table("comprobantes").insert({"tarea_id": req.tarea_id, "foto_url": req.foto_comprobante_url, "lat": req.lat, "lon": req.lon}).execute()
    except:
        pass
    pago = supabase.table("pagos_pendientes").select("*").eq("tarea_id", req.tarea_id).eq("estado","PENDIENTE_SPLIT").single().execute()
    if pago.data:
        supabase.table("pagos_pendientes").update({"estado":"LIBERADO","liberado_en":datetime.utcnow().isoformat()}).eq("tarea_id", req.tarea_id).execute()
        return {"ok": True, "liberado": {"monto_profesional_liberado": pago.data["monto_profesional"], "comision_nodo_retenida": pago.data["comision_nodo"], "accion": f"Transferir ${pago.data['monto_profesional']} a {req.email_profesional}"}}
    return {"ok": False}

@app.post("/api/v1/routing/ruta-real")
async def ruta_real(req: Solicitud):
    lon1, lat1 = req.origen['lon'], req.origen['lat']
    lon2, lat2 = req.destino['lon'], req.destino['lat']
    url = f"https://router.project-osrm.org/route/v1/driving/{lon1},{lat1};{lon2},{lat2}"
    params = {"overview":"full","geometries":"geojson","steps":"true"}
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(url, params=params)
        r.raise_for_status()
        data = r.json()
    route = data['routes'][0]
    tarifa = int(settings.NODO_BASE_FEE + (route['distance']/1000 * settings.NODO_PER_KM))
    return {"ruta": route, "tarifa_calles": tarifa, "distancia_km": round(route['distance']/1000,2)}

@app.get("/api/v1/bots/estado")
def bots_estado():
    return {"bots": [{"id": j.id, "nombre": j.name, "prox": str(j.next_run_time)} for j in scheduler.get_jobs()]}

@app.post("/api/v1/bots/ejecutar-ahora")
async def ejecutar_bots():
    from app.scrapers.scraper_catamarca_real import ejecutar_todos_los_bots_scrapers
    tareas = await ejecutar_todos_los_bots_scrapers()
    return {"ok": True, "encontradas": len(tareas), "tareas": tareas}

@app.get("/api/v1/mp/verificar-connect")
def verificar():
    try:
        bal = sdk.get("/v1/account/balance")
        return {"habilitado": True, "balance": bal}
    except Exception as e:
        return {"habilitado": False, "error": str(e), "instrucciones": "Activar MP Connect en developers.mercadopago.com.ar - Marketplace"}
