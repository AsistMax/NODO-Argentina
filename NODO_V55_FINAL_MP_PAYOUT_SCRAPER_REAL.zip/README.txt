NODO V55 REAL

Backend: subir a GitHub repo conectado a Render
Build: pip install -r backend/requirements.txt
Start: gunicorn backend.main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:$PORT

Frontend: backend ya sirve frontend/bloque1 en /bloque1 y / - No necesitas subir a otro lado

SQL: ejecutar SUPABASE_SQL_V55.sql en Supabase

MP Connect: developers.mercadopago.com.ar -> Marketplace -> Activar Connect para payouts

Para abrir index local: no doble click, usar Chrome, o python -m http.server 8000 en frontend/bloque1
